# Website Portofolio Ryan Ardiansyah

## Cara membuka
1. Ekstrak ZIP.
2. Pastikan index.html dan foto-ryan.jpg tetap berada dalam folder yang sama.
3. Buka index.html di browser.

Foto profil sudah dipasang pada bagian utama website.
